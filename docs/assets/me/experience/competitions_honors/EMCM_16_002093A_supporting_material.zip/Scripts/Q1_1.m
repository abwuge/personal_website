% 问题1：各园区独立运营储能配置方案及其经济性分析
% （1）分析未配置储能时各园区运行的经济性，包括：购电量、弃风弃光电量、总供电成本
% 和单位电量平均供电成本，并分析影响其经济性的关键因素；
function Q1_1()
%% 清理
if (nargin == 0)
    clc, close all;
end

%% 逐园区计算
cal("A", "ResultsName", "问题1(1)：未配置储能时各园区详细数据.xlsx");
cal("B", "ResultsName", "问题1(1)：未配置储能时各园区详细数据.xlsx");
cal("C", "ResultsName", "问题1(1)：未配置储能时各园区详细数据.xlsx");
cal("0", "ResultsName", "问题1(1)：未配置储能时各园区详细数据.xlsx");

end