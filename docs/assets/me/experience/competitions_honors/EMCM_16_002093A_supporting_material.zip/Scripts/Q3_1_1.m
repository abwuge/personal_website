% 问题 3：园区风、光、储能的协调配置方案及其经济性分析
% （1）分别按各园区独立运营、联合运营制定风光储协调配置方案；

% 由于遗传算法的特性，可能需要多次运行才能得到论文提供的最优解

function Q3_1_1()
%% 清理
if (nargin == 0)
    clc, close all;
end

%% 初始化
park = "A";  % 园区选择，由于只有3个园区，不做ALL选项了
dataPath = "../Data/";
loadDataFile = dataPath + "附件1：各园区典型日负荷数据.xlsx";
generationDataFile = dataPath + "附件2：各园区典型日风光发电数据.xlsx";
resultsName = "问题3(1)：最优风光储独立运营各园区详细数据.xlsx";
[pvNGen, wNGen, load] = readData(park, generationDataFile, loadDataFile);

%% 作为非线性优化问题进行求解
% 对每个园区有五个决策变量，x(1)代表储能容量，x(2)代表储能功率，x(3)代表日初始容量，x(4)代表光伏装机容量，x(5)代表风电装机容量

% 目标函数
fitnessfcn = @(x) calc(x, pvNGen, wNGen, load);

% 不等式约束 A * x <= b
% capacity >= power --> x(1) >= x(2) --> -x(1) + x(2) <= 0
A = [-1 1 0 0 0];
b = 0;

% 非线性约束（初始容量约束、投资回报期约束）
nonlcon = @(x) nonLCon(x, pvNGen, wNGen, load);

% 变量界限
lb = [1; 1; 0; 0; 0];
ub = Inf * ones(5, 1);

if park == "A"  % A园区只能光伏装机
    ub(5) = 0;
elseif park == "B" % B园区只能风电装机
    ub(4) = 0;
end

% 整数约束
intcon = [1 2 4 5];

% 选项设置
options = optimoptions("ga", "ConstraintTolerance", 1e-6);
% options = optimoptions("ga", "Display", "iter", "ConstraintTolerance", 1e-6);

% 调用ga求解
[x, fval] = ga(fitnessfcn, 5, A, b, [], [], lb, ub, nonlcon, intcon, options);
fprintf("容量：%dkWh；功率：%dkW；初始容量：%.2fkWh；光伏装机容量：%dkW；风电装机容量：%dkW；\n单位电量成本：%f元\n", x(1), x(2), x(3) + 0.1 * x(1), x(4), x(5), fval);

% 数据写入文件
cal(park, "ResultsName", resultsName, "Capacity", x(1), "Power", x(2),"IniCapacity", x(3), "PvIst", x(4), "wIst", x(5), "LoadInc", 1.5);
cal("0", "ResultsName", resultsName);

end

%% 非线性约束
function [c, ceq] = nonLCon(x, pvNGen, wNGen, load)
ceq = [];

netCost = 1;
pvCost = 0.4;
wCost = 0.5;

capacity = x(1) * 0.8;
power = x(2);
storage = [x(3); zeros(24, 1)];
pvIst = x(4);
wIst = x(5);

pvGen = pvIst .* pvNGen;
wGen = wIst .* wNGen;

% 购电量 & 弃风弃光电量
phPur = zeros(24, 1);
diffLG = load - (pvGen + wGen);
for i = 1:24
    if (diffLG(i) < 0)  % 负载小于发电，可以充电
        if (power > -diffLG(i))  % 充电功率足够
            if storage(i) - diffLG(i) * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) - diffLG(i) * 0.95;
            else  % 充满
                storage(i + 1) = capacity;
            end
        else % 充电功率受限制
            if storage(i) + power * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) + power * 0.95;
            else  % 充满
                storage(i + 1) = capacity;
            end
        end
    else  % 负载大于等于发电，可以放电
        if (power > diffLG(i))  % 放电功率足够
            if (storage(i) * 0.95 > diffLG(i))  % 储能足够
                storage(i + 1) = storage(i) - diffLG(i) / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        else  % 放电功率不足
            if (storage(i) * 0.95 > power)  % 储能足够
                phPur(i) = diffLG(i) - power;  % 购电
                storage(i + 1) = storage(i) - power / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        end
    end
end

% 购电成本
phPurCost = phPur .* netCost + pvGen .* pvCost + wGen .* wCost + ...
    (capacity * 1800 + power * 800) / (365 * 10 * 24);
tPurCost = sum(phPurCost);

c = [ ...
    abs(storage(25) - storage(1)); ... 日初始容量 --> abs(次日初始 - 首日初始) <= 0
    (2500 * pvIst + 3000 * wIst) - 365 * 5 * (sum(load) - tPurCost); ...  投资回报周期 --> 投资金额 - 5年 * (原购电成本 - 现购电成本) <= 0
    ];

end

%% 计算函数 (从cal函数精简而来，防止反复load降低效率)
function tAveCostPkw = calc(x, pvNGen, wNGen, load)

netCost = 1;
pvCost = 0.4;
wCost = 0.5;

capacity = x(1) * 0.8;
power = x(2);
storage = [x(3); zeros(24, 1)];
pvIst = x(4);
wIst = x(5);

pvGen = pvIst .* pvNGen;
wGen = wIst .* wNGen;

% 购电量 & 弃风弃光电量
phPur = zeros(24, 1);
diffLG = load - (pvGen + wGen);
for i = 1:24
    if (diffLG(i) < 0)  % 负载小于发电，可以充电
        if (power > -diffLG(i))  % 充电功率足够
            if storage(i) - diffLG(i) * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) - diffLG(i) * 0.95;
            else  % 充满
                storage(i + 1) = capacity;
            end
        else % 充电功率受限制
            if storage(i) + power * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) + power * 0.95;
            else  % 充满
                storage(i + 1) = capacity;
            end
        end
    else  % 负载大于等于发电，可以放电
        if (power > diffLG(i))  % 放电功率足够
            if (storage(i) * 0.95 > diffLG(i))  % 储能足够
                storage(i + 1) = storage(i) - diffLG(i) / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        else  % 放电功率不足
            if (storage(i) * 0.95 > power)  % 储能足够
                phPur(i) = diffLG(i) - power;  % 购电
                storage(i + 1) = storage(i) - power / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        end
    end
end

% 购电成本
phPurCost = phPur .* netCost + pvGen .* pvCost + wGen .* wCost + ...
    (capacity * 1800 + power * 800) / (365 * 10 * 24);
tPurCost = sum(phPurCost);

% 单位电量平均供电成本
tAveCostPkw = tPurCost / sum(load);

end

%% 数据读入函数（将数据读入函数独立）
function [pvNGen, wNGen, load] = readData(park, generationDataFile, loadDataFile)

switch park
    case "A"
        pvNGen = readmatrix(generationDataFile, "Range", "B4:B27");
        wNGen = zeros(24, 1);
        load = readmatrix(loadDataFile, "Range", "B2:B25") .* 1.5;
    case "B"
        pvNGen = zeros(24, 1);
        wNGen = readmatrix(generationDataFile, "Range", "C4:C27");
        load = readmatrix(loadDataFile, "Range", "C2:C25") .* 1.5;
    case "C"
        pvNGen = readmatrix(generationDataFile, "Range", "D4:D27");
        wNGen = readmatrix(generationDataFile, "Range", "E4:E27");
        load = readmatrix(loadDataFile, "Range", "D2:D25") .* 1.5;
    otherwise
        fprintf("[WORNING] 园区指定不正确！\n");
        pvNGen = -1;
        wNGen = -1;
        load = -1;
end

end
