% 问题1：各园区独立运营储能配置方案及其经济性分析
% （2）各园区分别配置 50kW/100kWh 储能，制定储能最优运行策略及购电计
% 划，分析各园区运行经济性是否改善，并解释其原因；

% SOC 允许范围为10% - 90%, 考虑到储能设备一旦建成将持续运营，除了刚开始充电，
% 其余时刻均保证最低电量在10%，所有时刻均需保证最高电量不超过90%，据此，
% 我们可以合理的认为每日可用的电池容量为总容量的80%。

% 电池无论何时充电或放电、使用光伏充电或使用风能充电，都不会有价值区别，据此，
% 我们将在电池能充电的第一时间充电，电池需要放电的第一时间放电。

function Q1_2()
%% 清理
if (nargin == 0)
    clc, close all;
end

%% 参数设定
capacity = 50;
resultsFile = sprintf("问题1(2)：配置储能%dkWh时最优解各园区详细数据.xlsx", capacity);

%% 逐园区计算
AveCostPkw = zeros(50, 1);
for power = 1:capacity
    AveCostPkw(power) = cal("A", "Capacity", capacity, "Power", power, "Quiet", true);
end
[~, power] = min(AveCostPkw);
cal("A", "ResultsName", resultsFile, "Capacity", capacity, "Power", power);
fprintf("  典型日单位电量平均供电成本最低对应储电功率, %dkW\n", power);

for power = 1:capacity
    AveCostPkw(power) = cal("B", "Capacity", capacity, "Power", power, "Quiet", true);
end
[~, power] = min(AveCostPkw);
cal("B", "ResultsName", resultsFile, "Capacity", capacity, "Power", power);
fprintf("  典型日单位电量平均供电成本最低对应储电功率, %dkW\n", power);

for power = 1:capacity
    AveCostPkw(power) = cal("C", "Capacity", capacity, "Power", power, "Quiet", true);
end
[~, power] = min(AveCostPkw);
cal("C", "ResultsName", resultsFile, "Capacity", capacity, "Power", power);
fprintf("  典型日单位电量平均供电成本最低对应储电功率, %dkW\n", power);

cal("0", "ResultsName", resultsFile);

end