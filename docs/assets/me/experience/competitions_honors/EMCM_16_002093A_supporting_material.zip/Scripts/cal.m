% 计算单个园区的购电量、弃风弃光电量、总供电成本和单位电量平均供电成本
function varargout = cal(park, varargin)
%% 输入参数处理
p = inputParser;

defaultDataPath = "../Data/";
addParameter(p, "DataPath", defaultDataPath, @isstring);

defaultResultsPath = "../Results/";
addParameter(p, "ResultsPath", defaultResultsPath, @isstring);

defaultResultsName = "results.xlsx";
addParameter(p, "ResultsName", defaultResultsName, @isstring);

defaultInitialize = false;
addParameter(p, "Initialize", defaultInitialize, @islogical);

defaultQuiet = false;
addParameter(p, "Quiet", defaultQuiet, @islogical);

defaultCapacity = 0;
addParameter(p, "Capacity", defaultCapacity, @isnumeric);

defaultPower = 0;
addParameter(p, "Power", defaultPower, @isnumeric);

defaultIniCapacity = 0;
addParameter(p, "IniCapacity", defaultIniCapacity, @isnumeric);

defaultPvIst = (park == "A") * 750 + (park == "C") * 600;
addParameter(p, "PvIst", defaultPvIst, @isnumeric);

defaultWIst = (park == "B") * 1000 + (park == "C") * 500;
addParameter(p, "WIst", defaultWIst, @isnumeric);

defaultLoadInc = 1;
addParameter(p, "LoadInc", defaultLoadInc, @isnumeric);

parse(p, varargin{:});

dataPath = p.Results.DataPath;
resultsPath = p.Results.ResultsPath;
resultsName = p.Results.ResultsName;
Initialize = p.Results.Initialize;
quiet = p.Results.Quiet;
capacity = p.Results.Capacity * 0.8;
power = p.Results.Power;
iniCapacity = p.Results.IniCapacity;
pvIst = p.Results.PvIst;
wIst = p.Results.WIst;
loadInc = p.Results.LoadInc;

resultsFile = resultsPath + resultsName;
loadDataFile = dataPath + "附件1：各园区典型日负荷数据.xlsx";
generationDataFile = dataPath + "附件2：各园区典型日风光发电数据.xlsx";

netCost = 1;
pvCost = 0.4;
wCost = 0.5;

%% 园区单独化设置
switch park
    case "A"
        resultsRange = "B2:B25";
        resultsRange2 = "B2:B26";
        pvGen = readmatrix(generationDataFile, "Range", "B4:B27") .* pvIst;
        wGen = zeros(24, 1);
    case "B"
        resultsRange = "C2:C25";
        resultsRange2 = "C2:C26";
        pvGen = zeros(24, 1);
        wGen = readmatrix(generationDataFile, "Range", "C4:C27") .* wIst;
    case "C"
        resultsRange = "D2:D25";
        resultsRange2 = "D2:D26";
        pvGen = readmatrix(generationDataFile, "Range", "D4:D27") .* pvIst;
        wGen = readmatrix(generationDataFile, "Range", "E4:E27") .* wIst;
    otherwise
        fprintf("[WORNING] 园区指定不正确！将仅执行初始化功能！\n");
        Initialize = true;
end

%% 初始化非数据部分
if (~quiet && Initialize)
    % 时间
    time = strings(24, 1);
    for i = 0:23
        time(i + 1) = sprintf("%02d:00", i);
    end
    writematrix(time, resultsFile, "Sheet", "购电量", "Range", "A2:A25");
    writematrix(time, resultsFile, "Sheet", "弃风弃光电量", "Range", "A2:A25");
    writematrix(time, resultsFile, "Sheet", "购电成本", "Range", "A2:A25");
    writematrix(time, resultsFile, "Sheet", "单位电量平均供电成本", "Range", "A2:A25");
    writematrix([time; "00:00"], resultsFile, "Sheet", "储电量", "Range", "A2:A26");

    title = ["时间 (h)" "园区A购电量 (kWh)" "园区B购电量 (kWh)" "园区C购电量 (kWh)"];
    writematrix(title, resultsFile, "Sheet", "购电量", "Range", "A1:D1");
    title = ["时间 (h)" "园区A弃风弃光电量 (kWh)" "园区B弃风弃光电量 (kWh)" "园区C弃风弃光电量 (kWh)"];
    writematrix(title, resultsFile, "Sheet", "弃风弃光电量", "Range", "A1:D1");
    title = ["时间 (h)" "园区A购电成本 (元)" "园区B购电成本 (元)" "园区C购电成本 (元)"];
    writematrix(title, resultsFile, "Sheet", "购电成本", "Range", "A1:D1");
    title = ["时间 (h)" "园区A单位电量平均供电成本 (元)" "园区B单位电量平均供电成本 (元)" "园区C单位电量平均供电成本 (元)"];
    writematrix(title, resultsFile, "Sheet", "单位电量平均供电成本", "Range", "A1:D1");
    title = ["时间 (h)" "园区A储电量 (kWh)" "园区B储电量 (kWh)" "园区C储电量 (kWh)"];
    writematrix(title, resultsFile, "Sheet", "储电量", "Range", "A1:D1");
end

%% 读取数据
if ~exist("resultsRange", "var")
    return;
end
load = readmatrix(loadDataFile, "Range", resultsRange) * loadInc;

%% 购电量 & 弃风弃光电量
% ph -> per hour，每小时
% t -> total，总
% pur -> purchase，(从电网)购买(的电量)
% aban -> abandon，放弃，即弃(风弃光电量)
% diffLG -> difference between load and power generation，负载发电差

storage = [iniCapacity; zeros(24, 1)];
phPur = zeros(24, 1);
phAban = zeros(24, 1);

diffLG = load - (pvGen + wGen);
for i = 1:24
    if (diffLG(i) < 0)  % 负载小于发电，可以充电
        if (power > -diffLG(i))  % 充电功率足够
            if storage(i) - diffLG(i) * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) - diffLG(i) * 0.95;
            else  % 充满
                phAban(i) = - diffLG(i) - (capacity - storage(i)) / 0.95;  % 弃电
                storage(i + 1) = capacity;
            end
        else % 充电功率受限制
            if storage(i) + power * 0.95 < capacity  % 不能充满
                phAban(i) = - diffLG(i) - power;
                storage(i + 1) = storage(i) + power * 0.95;
            else  % 充满
                phAban(i) = - diffLG(i) - (capacity - storage(i)) / 0.95;  % 弃电
                storage(i + 1) = capacity;
            end
        end
    else  % 负载大于等于发电，可以放电
        if (power > diffLG(i))  % 放电功率足够
            if (storage(i) * 0.95 > diffLG(i))  % 储能足够
                storage(i + 1) = storage(i) - diffLG(i) / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        else  % 放电功率不足
            if (storage(i) * 0.95 > power)  % 储能足够
                phPur(i) = diffLG(i) - power;  % 购电
                storage(i + 1) = storage(i) - power / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        end
    end
end
storage = storage + 0.1 * p.Results.Capacity;

if ~quiet, writematrix(phPur, resultsFile, "Sheet", "购电量", "Range", resultsRange); end
tPur = sum(phPur);

if ~quiet, writematrix(phAban, resultsFile, "Sheet", "弃风弃光电量", "Range", resultsRange); end
tAban = sum(phAban);

if ~quiet, writematrix(storage, resultsFile, "Sheet", "储电量", "Range", resultsRange2); end
aveStorage = sum(storage) / 24;

%% 购电成本
% ph -> per hour，每小时
% t -> total，总
% purCost -> the cost of purchasing, 购(电)成本
% 考虑到实际情况，我们认为，弃风弃光仍正常发电，即仍计入成本

phPurCost = phPur .* netCost + pvGen .* pvCost + wGen .* wCost + ...
    (capacity * 1800 + power * 800) / (365 * 10 * 24);
if ~quiet, writematrix(phPurCost, resultsFile, "Sheet", "购电成本", "Range", resultsRange); end
tPurCost = sum(phPurCost);

%% 单位电量平均供电成本
% ph -> per hour，每小时
% t -> total，总
% aveCostPkw 每度电平均成本
% 考虑到实际情况，我们认为，有效电量为此时的负载耗电量

phAveCostPkw = phPurCost ./ load;
if ~quiet, writematrix(phAveCostPkw, resultsFile, "Sheet", "单位电量平均供电成本", "Range", resultsRange); end
tAveCostPkw = tPurCost / sum(load);

%% 打印结果
if ~quiet
    fprintf("园区%s（光伏装机容量%dkW，风电装机容量%dkW）:\n", park, pvIst, wIst);
    fprintf("  典型日购电量, %.2fkWh;\n", tPur);
    fprintf("  典型日弃风弃光电量, %.2fkWh;\n", tAban);
    fprintf("  典型日购电成本, %.2f元;\n", tPurCost);
    fprintf("  典型日单位电量平均供电成本, %f元;\n", tAveCostPkw);
    fprintf("  典型日日均储能，%.2fkWh，结束时储能，%.2fkWh;\n", aveStorage, storage(25));
end

%% 返回结果
switch nargout
    case 1
        varargout{1} = tAveCostPkw;
end

end