% 问题 2：联合园区储能配置方案及其经济性分析
% （2）假设风光荷功率波动特性保持上述条件不变，制定联合园区的总储能
% 最优配置方案，给出储能运行策略及购电计划，分析其经济性；

% 由于遗传算法的特性，可能需要多次运行才能得到论文提供的最优解

function Q2_2()
%% 清理
if (nargin == 0)
    clc, close all;
end

%% 初始化
dataPath = "../Data/";
loadDataFile = dataPath + "附件1：各园区典型日负荷数据.xlsx";
generationDataFile = dataPath + "附件2：各园区典型日风光发电数据.xlsx";
resultsName = "问题2(2)：配置储能时最优解联合园区详细数据.xlsx";
[pvGen, wGen, load] = readData(generationDataFile, loadDataFile);

%% 作为非线性优化问题进行求解
% 对每个园区有三个决策变量，x(1)代表容量，x(2)代表功率，x(3)代表日初始容量

% 目标函数
fitnessfcn = @(x) calc(x, pvGen, wGen, load);

% 不等式约束 A * x <= b
% capacity >= power --> x(1) >= x(2) --> -x(1) + x(2) <= 0
A = [-1 1 0];
b = 0;

% 非线性约束（初始容量约束）
nonlcon = @(x) initialCapacity(x, pvGen, wGen, load);

% 变量界限
lb = [1; 1; 0];
ub = Inf * ones(3, 1);

% 整数约束
intcon = [1 2];

% 选项设置
options = optimoptions("ga", "ConstraintTolerance", 1e-6);
% options = optimoptions("ga", "Display", "iter", "ConstraintTolerance", 1e-6);

% 调用ga求解
[x, fval] = ga(fitnessfcn, 3, A, b, [], [], lb, ub, nonlcon, intcon, options);
fprintf("容量：%dkWh；功率：%dkW；初始容量：%.2fkWh；\n单位电量成本：%f元\n", x(1), x(2), x(3) + 0.1 * x(1), fval);

% 数据写入文件
calU("ResultsName", resultsName, "Capacity", x(1), "Power", x(2));

end

%% 日初始容量约束
function [c, ceq] = initialCapacity(x, pvGen, wGen, load)
ceq = [];

capacity = x(1) * 0.8;
power = x(2);
storage = [x(3); zeros(24, 1)];
diffLG = load - (pvGen + wGen);
for i = 1:24
    if (diffLG(i) < 0)  % 负载小于发电，可以充电
        if (power > -diffLG(i))  % 充电功率足够
            if storage(i) - diffLG(i) * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) - diffLG(i) * 0.95;
            else  % 充满
                storage(i + 1) = capacity;
            end
        else % 充电功率受限制
            if storage(i) + power * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) + power * 0.95;
            else  % 充满
                storage(i + 1) = capacity;
            end
        end
    else  % 负载大于等于发电，可以放电
        if (power > diffLG(i))  % 放电功率足够
            if (storage(i) * 0.95 > diffLG(i))  % 储能足够
                storage(i + 1) = storage(i) - diffLG(i) / 0.95;
            end
        else  % 放电功率不足
            if (storage(i) * 0.95 > power)  % 储能足够
                storage(i + 1) = storage(i) - power / 0.95;
            end
        end
    end
end

c = abs(storage(25) - storage(1));

end

%% 计算函数 (从cal函数精简而来，防止反复load降低效率)
function tAveCostPkw = calc(x, pvGen, wGen, load)

netCost = 1;
pvCost = 0.4;
wCost = 0.5;

capacity = x(1) * 0.8;
power = x(2);

% 购电量 & 弃风弃光电量
storage = [x(3); zeros(24, 1)];
phPur = zeros(24, 1);
phAban = zeros(24, 1);

diffLG = load - (pvGen + wGen);
for i = 1:24
    if (diffLG(i) < 0)  % 负载小于发电，可以充电
        if (power > -diffLG(i))  % 充电功率足够
            if storage(i) - diffLG(i) * 0.95 < capacity  % 不能充满
                storage(i + 1) = storage(i) - diffLG(i) * 0.95;
            else  % 充满
                phAban(i) = - diffLG(i) - (capacity - storage(i)) / 0.95;  % 弃电
                storage(i + 1) = capacity;
            end
        else % 充电功率受限制
            if storage(i) + power * 0.95 < capacity  % 不能充满
                phAban(i) = - diffLG(i) - power;
                storage(i + 1) = storage(i) + power * 0.95;
            else  % 充满
                phAban(i) = - diffLG(i) - (capacity - storage(i)) / 0.95;  % 弃电
                storage(i + 1) = capacity;
            end
        end
    else  % 负载大于等于发电，可以放电
        if (power > diffLG(i))  % 放电功率足够
            if (storage(i) * 0.95 > diffLG(i))  % 储能足够
                storage(i + 1) = storage(i) - diffLG(i) / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        else  % 放电功率不足
            if (storage(i) * 0.95 > power)  % 储能足够
                phPur(i) = diffLG(i) - power;  % 购电
                storage(i + 1) = storage(i) - power / 0.95;
            else  % 储能不足
                phPur(i) = diffLG(i) - storage(i) * 0.95;  % 购电
                storage(i + 1) = 0;
            end
        end
    end
end

% 购电成本
phPurCost = phPur .* netCost + pvGen .* pvCost + wGen .* wCost + ...
    (capacity * 1800 + power * 800) / (365 * 10 * 24);
tPurCost = sum(phPurCost);

% 单位电量平均供电成本
tAveCostPkw = tPurCost / sum(load);

end

%% 数据读入函数（将数据读入函数独立）
function [pvGen, wGen, load] = readData(generationDataFile, loadDataFile)

% A园区光伏 + C园区光伏
pvGen = readmatrix(generationDataFile, "Range", "B4:B27") .* 750 + ...
    readmatrix(generationDataFile, "Range", "D4:D27") .* 600;

% B园区风能 + C园区风能
wGen = readmatrix(generationDataFile, "Range", "C4:C27") .* 1000 + ...
    readmatrix(generationDataFile, "Range", "E4:E27") .* 500;

% 按行求和得到联合园区负载
load = sum(readmatrix(loadDataFile, "Range", "B2:D25"), 2);

end
